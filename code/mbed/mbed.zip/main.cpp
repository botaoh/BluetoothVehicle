// Hello World to sweep a servo through its full range

#include "mbed.h"
#include "Servo.h"
#include "Motor.h"
#include "uLCD_4DGL.h"

//Pi mbed USB Slave function
// connect mbed to Pi USB
RawSerial  pi(USBTX, USBRX);

uLCD_4DGL uLCD(p28,p27,p29); // serial tx, serial rx, reset pin;

DigitalOut trigger(p6);
DigitalIn  echo(p7);

int RadarReturnDistance = 0;

Motor DLMotor(p25, p13, p12); // pwm, fwd, rev
Motor DRMotor(p26, p10, p9); // pwm, fwd, rev

DigitalOut bit0(LED1);
DigitalOut bit1(LED2);
DigitalOut bit2(LED3);
DigitalOut bit3(LED4);

DigitalOut red(p20);//"R" pin

int color[3] = {RED, GREEN, BLUE};

int mode = 0;

void dev_recv()
{
    char temp = 0;
    while(pi.readable()) {
        temp = pi.getc();
        pi.putc(temp);
        if (temp=='w')
        {
            mode = 1;

        }
        else if (temp=='a')
        {
            mode = 2;
        }        
        else if (temp=='s')
        {
            mode = 3;
        }        
        else if (temp=='d')
        {
            mode = 4;
        }
        else if (temp=='a')
        {
            mode = 5;
        }
        else if (temp=='x')
        {
            mode = 6;
        }
        else if (temp=='y')
        {
            mode = 7;
        }
        else if (temp=='b')
        {
            mode = 8;
        }
        else
        {
            mode = 0;
        }
    }
}

double unit = (3.0 - 0.0)/16;
float constSpeed = 0.8;
void ledClear() {
    bit0 = 0;
    bit1 = 0;
    bit2 = 0;
    bit3 = 0;
}

void sleep_unit() {
    wait_us(100000);
}

void moveForward() {
    ledClear();
    bit0 = 1;
    float currentSpeed = constSpeed;
    DLMotor.speed(currentSpeed); 
    DRMotor.speed(currentSpeed);
}

void moveInverse() {
    ledClear();
    bit1 = 1;
    float currentSpeed = -constSpeed;
    DLMotor.speed(currentSpeed); 
    DRMotor.speed(currentSpeed);
}

void moveLeft() {
    ledClear();
    bit2 = 1;
    float currentSpeed = constSpeed;
    DLMotor.speed(-currentSpeed); 
    DRMotor.speed(currentSpeed);
}

void moveRight() {
    ledClear();
    bit3 = 1;
    float currentSpeed = constSpeed;
    DLMotor.speed(currentSpeed); 
    DRMotor.speed(-currentSpeed);
}

void stopMove() {
    ledClear();
    DLMotor.speed(0); 
    DRMotor.speed(0);
}

void LCD_Show()
{
    uLCD.cls();
    int len = snprintf(NULL, 0, "%d", RadarReturnDistance);
    char *result = (char*)malloc(len + 1);
    snprintf(result, len + 1, "%d", RadarReturnDistance);

    uLCD.puts(result);
}

//sonor part
int objectDistance = 0;
int correction = 0;
Timer sonar;
void sonor_init()
{
    //sonor init
    sonar.reset();
    // measure actual software polling timer delays
    // delay used later in time correction
    // start timer
    sonar.start();
    // min software polling delay to read echo pin
    while (echo==2) {};
    // stop timer
    sonar.stop();
    // read timer
    correction = sonar.read_us();
    printf("Approximate software overhead timer delay is %d uS\n\r",correction);
}

void sonor_thread()
{
    // trigger sonar to send a ping
    trigger = 1;
    sonar.reset();
    wait_us(10.0);
    trigger = 0;
    //wait for echo high
    while (echo==0) {};
    //echo high, so start timer
    sonar.start();
    //wait for echo low
    while (echo==1) {};
    //stop timer and read value
    sonar.stop();
    //subtract software overhead timer delay and scale to cm
    objectDistance = (sonar.read_us()-correction)/148.0;
    printf(" %d inch \n\r",objectDistance);
    //wait so that any echo(s) return before sending another ping
    // Very Important!!!!!!
    wait_ms(200);
    RadarReturnDistance = objectDistance;

    //Control Light
    if (objectDistance < 3)
    {
        red = 1;
    }
    else
    {
        red = 0;
    }
}


int main() {  
    pi.baud(9600);
    pi.attach(&dev_recv, Serial::RxIrq);
    sonor_init();
    sleep();
    while (true)
    { 
        // wait 
        switch (mode) {
            case 1:
                if (objectDistance < 3)
                {
                    stopMove();
                }
                else
                {
                    moveForward();
                }
                break;
            case 2:
                moveLeft();
                break;
            case 3:
                moveInverse();
                break;
            case 4:
                moveRight();
                break;
            case 0:
                stopMove();
                break;
        }
        LCD_Show();
        sonor_thread();
    }
}